import torch
import torch.nn as nn
from torch.nn import functional as F
import math

class LoRALinear(nn.Linear):

    def __init__(self,
                 # nn.Linear parameters
                 in_features: int,
                 out_features: int,
                 bias: bool = True,
                 device=None,
                 dtype=None,
                 # LoRA parameters
                 lora_rank: int = 0,
                 lora_alpha: float = 0.0,
                 lora_dropout: float = 0.0,
                ) -> None:
        
        # ====== BEGIN STUDENT SOLUTION ======
        #TODO: Initialize the inherited class, nn.linear 
        # ====== END STUDENT SOLUTION ======
        
        self.has_weights_merged = False
        if lora_rank > 0:
            
            # ====== BEGIN STUDENT SOLUTION ======
            self.lora_dropout = # TODO
            self.lora_scaling = # TODO

            self.lora_A = # TODO
            self.lora_B = # TODO
            # ====== END STUDENT SOLUTION ======
             
            self.lora_A.requires_grad = False
            self.lora_B.requires_grad = False

            self.reset_parameters()

    def is_lora(self) -> bool:
        return hasattr(self, 'lora_A')

    def reset_parameters(self) -> None:
        nn.Linear.reset_parameters(self)
        if self.is_lora():
            #TODO: Initialize both lora_A and lora_B with torch.nn.init. Refer to the paper to see how each is initialized
            # Hint: lora_A is initialized using kaiming_uniform_ using negative slope (a) as math.sqrt(5)
            # ====== BEGIN STUDENT SOLUTION ======
            
            # ====== END STUDENT SOLUTION ======
            raise NotImplementedError

    def forward(self, input: torch.Tensor) -> torch.Tensor:
        #TODO: return input after the forward pass
        #TODO: Remember to use dropout on the input before multiplying with lora_B and lora_A if the weights are not merged
        # ====== BEGIN STUDENT SOLUTION ======
            
        # ====== END STUDENT SOLUTION ======
        raise NotImplementedError

    def train(self, mode: bool = True) -> "LoRALinear":
        #TODO: Set the linear layer into train mode
        # Hint: Make sure to demerge LORA matrices if already merged
        # ====== BEGIN STUDENT SOLUTION ======
            
        # ====== END STUDENT SOLUTION ======
        raise NotImplementedError
        return self

    def eval(self) -> "LoRALinear":
        #TODO: Set the linear layer into eval mode
        # Hint: Make sure to merge LORA matrices if already demerged
        # ====== BEGIN STUDENT SOLUTION ======
            
        # ====== END STUDENT SOLUTION ======
        return self
    
    def extra_repr(self) -> str:
        out = nn.Linear.extra_repr(self)
        if self.is_lora():
            out += f', lora_rank={self.lora_A.shape[0]}, lora_scaling={self.lora_scaling}, lora_dropout={self.lora_dropout.p}'
        return out

def mark_only_lora_as_trainable(model: nn.Module) -> nn.Module:
    #TODO: Loop through parameters and mark some as trainable. Which ones should these be?
    # Hint: How do you mark a parameter as trainable (or not trainable)?
    # ====== BEGIN STUDENT SOLUTION ======
            
    # ====== END STUDENT SOLUTION ======
    raise NotImplementedError
    return model
